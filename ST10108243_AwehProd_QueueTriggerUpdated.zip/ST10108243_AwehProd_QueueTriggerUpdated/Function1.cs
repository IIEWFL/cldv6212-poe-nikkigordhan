using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Storage.Blob.Protocol;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace ST10108243_AwehProd_QueueTriggerUpdated
{
    public class Function1
    { 
        [FunctionName("TableStorage")]
        public async Task Run([QueueTrigger("vaccination-queue", Connection = "CONNECTION_STRING")] string myQueueItem, 
        [Table ("Message", Connection = "CONNECTION_STRING")] CloudTable cloudTable, ILogger log)
        {
            try
            {
                string sEncodeMessage = Convert.ToBase64String(Encoding.UTF8.GetBytes(myQueueItem));
                // encodes the message to a 64 byte.
                // the line of code was taken and adapted from StackOverflow.
                // https://stackoverflow.com/questions/11743160/how-do-i-encode-and-decode-a-base64-string
                // Zeigeist
                // https://stackoverflow.com/users/2649698/zeigeist

                string[] messageParts = Encoding.UTF8.GetString(Convert.FromBase64String(sEncodeMessage)).Split(':');
                // seperates the string when ever there is a ':'.
                // the line of code above was taken and adapted from Microsoft Documenets.
                // https://learn.microsoft.com/en-us/dotnet/api/system.convert.frombase64string?view=net-7.0

                //assumptions

                //if else firt element is 13 or 10 then it first format else its the second format
                string sID = "";
                string sCenter = "";
                string sVaccination_Date = "";
                string sSerial_Number = "";


                if (messageParts[0].Length == 13 || messageParts[0].Length == 10)
                {
                    // format 1- Id:VaccinationCenter:VaccinationDate:VaccineSerialNumber
                    sID = messageParts[0];
                    sCenter = messageParts[1];
                    sVaccination_Date = messageParts[2];
                    sSerial_Number = messageParts[3];
                }
                else
                {
                    // format 2- VaccineBarcode:VaccinationDate:VaccinationCenter:Id
                    sID = messageParts[3];
                    sCenter = messageParts[2];
                    sVaccination_Date = messageParts[1];
                    sSerial_Number = messageParts[0];
                }
                // assigns the columns into the array elements.

                //CREATE A NEW MESSSAGE ENTITY:
                    MessageEntity messageEntity = new MessageEntity(sID,sCenter,sVaccination_Date,sSerial_Number);
                // create a MessageEnitity object that passes in the values.

                //CREATE A TABLE OPERATION TO INSERT THE ENTITY:
                TableOperation insertOperation = TableOperation.Insert(messageEntity);
                // inserts the messages from the MessageEntity object.

                //EXECUTE THE INSERT OPERATION:
                await cloudTable.ExecuteAsync(insertOperation);
                // executes the insertoperation.

                log.LogInformation($"Queue message has been stored successfully in the database ID = {sID}, Center = {sCenter}, Vaccination_Date = {sVaccination_Date}, Serial_Number = {sSerial_Number} ");
            }
            catch (Exception ex)
            {
                log.LogError($"Error in processing the queue message: {ex.Message}");
            }
            
        }

        public class MessageEntity : TableEntity
        {
            public MessageEntity(string sID, string sCenter, string sVaccination_Date, string sSerial_Number)
            {
                PartitionKey = "Incoming";
                RowKey = Guid.NewGuid().ToString();
                ID = sID;
                Center = sCenter;
                Vaccination_Date = sVaccination_Date;
                Serial_Number = sSerial_Number;
            }
            // gives the Message entity colunm headings.

            public MessageEntity() { }

            public string ID { get; set; }
            public string Center { get; set; }
            public string Vaccination_Date { get; set; }
            public string Serial_Number { get; set; }
            // getters and setter for each of the columns in the MessageEntity.

        }
    }
}
