﻿using Azure.Messaging;
using Azure.Storage.Queues;
using System.Text;
//calls the libraries that are needed.

// CONNECTION STRING:
    string sConnectionString = "DefaultEndpointsProtocol=https;AccountName=sast10108243;AccountKey=KROMgMKONLB2aMlnn9Ve4UZKN2lLvOUAziCpqY6BvxpIp3zVhPiDLmKYHmvP+motLk6AJwvodbBF+ASt640p/Q==;EndpointSuffix=core.windows.net";
    // gets the connection string.

// CREATES  THE QUEUE:
    string sQueueName = "vaccination-queue";
    //assings the queue name to a variable.

    QueueClient queueClient = new QueueClient(sConnectionString, sQueueName);
        // the line of code above was taken and adapted from Microsoft Documents.
        // https://learn.microsoft.com/en-us/dotnet/api/azure.storage.queues.queueclient?view=azure-dotnet

Console.WriteLine($"Creating the queue {sQueueName}");
    await queueClient.CreateIfNotExistsAsync();
//creates the queue if it does not exit.
    //the line of code above was taken and adapted from Microsoft Documents.
    //https://learn.microsoft.com/en-us/azure/storage/queues/storage-quickstart-queues-dotnet?tabs=passwordless%2Croles-azure-portal%2Cenvironment-variable-windows%2Csign-in-azure-cli#create-a-queue

// INSERTS MESSAGES:
Console.WriteLine($"\nAdding the messages to {sQueueName}.");

    string m1 = "9405105021537:HealthClinic1:21-08-2023:VSNVAR2102023";
    queueClient.SendMessage(Convert.ToBase64String(Encoding.UTF8.GetBytes(m1)));

    string m2 = "A274914658:HealthClinic2:21-08-2023:VSNVAR21082023";
    queueClient.SendMessage(Convert.ToBase64String(Encoding.UTF8.GetBytes(m2)));

    string m3 = "VBNVAR21082023:21-08-2023:HealthClinic3:6285429502175";
    queueClient.SendMessage(Convert.ToBase64String(Encoding.UTF8.GetBytes(m3)));

    string m4 = "VBNVAR21082025:21-08-2023:HealthClinic4:A285936254";
    queueClient.SendMessage(Convert.ToBase64String(Encoding.UTF8.GetBytes(m4)));

    string m5 = "VBN2619476:21-08-2023:HealthClinic5:2741037572539";
    queueClient.SendMessage(Convert.ToBase64String(Encoding.UTF8.GetBytes(m5)));
//messages to add to the queue.
// the code above(sending messages to the queue) was taken and adapted from StackOverflow.
// https://stackoverflow.com/questions/63023481/azure-functions-queue-trigger-is-expecting-base-64-messages-and-doesnt-process
// Johan Classon
// https://stackoverflow.com/users/1482279/johan-classon

Console.WriteLine("Execution Completed");